package com.example.day10_bagus;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.Locale;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);


        String selectedCar = getIntent().getStringExtra("selectedCar");
        String selectedCity = getIntent().getStringExtra("selectedCity");
        int rentDays = getIntent().getIntExtra("rentDays", 0);
        double totalPrice = getIntent().getDoubleExtra("totalPrice", 0);


        double carRentalPricePerDay;
        switch (selectedCar) {
            case "Pajero":
                carRentalPricePerDay = 2400000;
                break;
            case "Alphard":
                carRentalPricePerDay = 1550000;
                break;
            case "Innova":
                carRentalPricePerDay = 850000;
                break;
            case "Brio":
                carRentalPricePerDay = 550000;
                break;
            default:
                carRentalPricePerDay = 0;
        }


        TextView tvSelectedCar = findViewById(R.id.tvSelectedCity);
        TextView tvSelectedCity = findViewById(R.id.tvSelectedCity);
        TextView tvRentDuration = findViewById(R.id.tvRentDuration);
        TextView tvDiscount = findViewById(R.id.tvDiscount);
        TextView tvCarRentPrice = findViewById(R.id.tvCarRentPrice);
        TextView tvTotalPrice = findViewById(R.id.tvTotalPrice);
        TextView tvCityPrice = findViewById(R.id.tvCityPrice);


        tvSelectedCar.setText("Mau Mobil Apa : " + selectedCar);
        tvSelectedCity.setText("Tujuan : " + selectedCity);
        tvRentDuration.setText("Rental Duration : " + rentDays + " days");


        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        String formattedCarRentalPricePerDay = formatRupiah.format(carRentalPricePerDay);
        tvCarRentPrice.setText("Harga Rental Perhari : " + formattedCarRentalPricePerDay);


        double cityPrice = 0;
        if (selectedCity.equals("Inside city")) {
            cityPrice = 135000;
        } else if (selectedCity.equals("Outside city")) {
            cityPrice = 250000;
        }
        String formattedCityPrice = formatRupiah.format(cityPrice);
        tvCityPrice.setText("Harga Tambahan Kota: " + formattedCityPrice);


        double discount = 0;
        if (totalPrice > 10000000) {
            discount = totalPrice * 0.07;
        } else if (totalPrice > 5000000) {
            discount = totalPrice * 0.05;
        }


        String formattedDiscount = formatRupiah.format(discount);
        String formattedTotalPrice = formatRupiah.format(totalPrice);
        tvDiscount.setText("Discount : " + formattedDiscount);
        tvTotalPrice.setText("Total Pembayaran : " + formattedTotalPrice);
    }
}